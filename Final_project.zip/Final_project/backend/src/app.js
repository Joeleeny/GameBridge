const express = require("express");
const cors = require("cors");
const seniorsRoutes = require("./routes/seniors");
const studentsRoutes = require("./routes/students");
const gamesRoutes = require("./routes/games");
const consolesRoutes = require("./routes/consoles");
const bookingsRoutes = require("./routes/bookings");

const app = express();

app.use(cors());
app.use(express.json());
app.use("/api/seniors", seniorsRoutes);
app.use("/api/students", studentsRoutes);
app.use("/api/games", gamesRoutes);
app.use("/api/consoles", consolesRoutes);
app.use("/api/bookings", bookingsRoutes);

// test route
app.get("/", (req, res) => {
  res.json({ message: "Backend is running" });
});

module.exports = app;

const db = require("./config/db");

// test database connection
app.get("/test-db", async (req, res) => {
  try {
    const [rows] = await db.query("SELECT 1 AS test");
    res.json({
      message: "Database connected!",
      result: rows
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Database connection failed"
    });
  }
});