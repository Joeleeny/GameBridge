const express = require("express");
const router = express.Router();
const db = require("../config/db");

// GET all consoles
router.get("/", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT
        console_id,
        console_name,
        brand,
        platform,
        quantity_total,
        quantity_available,
        max_players,
        status,
        condition_notes
      FROM consoles
      ORDER BY console_id
    `);

    res.json(rows);
  } catch (error) {
    console.error("Error fetching consoles:", error);
    res.status(500).json({ error: "Failed to fetch consoles" });
  }
});

// POST create console
router.post("/", async (req, res) => {
  try {
    const {
      console_name,
      brand,
      platform,
      quantity_total,
      quantity_available,
      max_players,
      status,
      condition_notes
    } = req.body;

    if (!console_name || !platform) {
      return res.status(400).json({
        error: "console_name and platform are required"
      });
    }

    const [result] = await db.query(
      `
      INSERT INTO consoles (
        console_name,
        brand,
        platform,
        quantity_total,
        quantity_available,
        max_players,
        status,
        condition_notes
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        console_name,
        brand || null,
        platform,
        quantity_total ?? 1,
        quantity_available ?? quantity_total ?? 1,
        max_players ?? 1,
        status || "available",
        condition_notes || null
      ]
    );

    res.status(201).json({
      message: "Console created successfully",
      console_id: result.insertId
    });
  } catch (error) {
    console.error("Error creating console:", error);
    res.status(500).json({ error: "Failed to create console" });
  }
});

module.exports = router;