const express = require("express");
const router = express.Router();
const db = require("../config/db");

// GET all students
router.get("/", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT
        student_id,
        first_name,
        last_name,
        phone,
        email,
        user_id
      FROM students
      ORDER BY student_id
    `);

    res.json(rows);
  } catch (error) {
    console.error("Error fetching students:", error);
    res.status(500).json({ error: "Failed to fetch students" });
  }
});

// POST create student
router.post("/", async (req, res) => {
  try {
    const { first_name, last_name, phone, email, user_id } = req.body;

    if (!first_name || !last_name) {
      return res.status(400).json({
        error: "first_name and last_name are required"
      });
    }

    const [result] = await db.query(
      `
      INSERT INTO students (
        first_name,
        last_name,
        phone,
        email,
        user_id
      )
      VALUES (?, ?, ?, ?, ?)
      `,
      [
        first_name,
        last_name,
        phone || null,
        email || null,
        user_id || null
      ]
    );

    res.status(201).json({
      message: "Student created successfully",
      student_id: result.insertId
    });
  } catch (error) {
    console.error("Error creating student:", error);
    res.status(500).json({ error: "Failed to create student" });
  }
});

module.exports = router;