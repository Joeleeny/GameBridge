const express = require("express");
const router = express.Router();
const db = require("../config/db");

// GET all games
router.get("/", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT
        game_id,
        game_title,
        genre,
        platform,
        age_rating,
        quantity_total,
        quantity_available,
        status,
        condition_notes
      FROM games
      ORDER BY game_id
    `);

    res.json(rows);
  } catch (error) {
    console.error("Error fetching games:", error);
    res.status(500).json({ error: "Failed to fetch games" });
  }
});

// POST create game
router.post("/", async (req, res) => {
  try {
    const {
      game_title,
      genre,
      platform,
      age_rating,
      quantity_total,
      quantity_available,
      status,
      condition_notes
    } = req.body;

    if (!game_title || !platform) {
      return res.status(400).json({
        error: "game_title and platform are required"
      });
    }

    const [result] = await db.query(
      `
      INSERT INTO games (
        game_title,
        genre,
        platform,
        age_rating,
        quantity_total,
        quantity_available,
        status,
        condition_notes
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        game_title,
        genre || null,
        platform,
        age_rating || null,
        quantity_total ?? 1,
        quantity_available ?? quantity_total ?? 1,
        status || "available",
        condition_notes || null
      ]
    );

    res.status(201).json({
      message: "Game created successfully",
      game_id: result.insertId
    });
  } catch (error) {
    console.error("Error creating game:", error);
    res.status(500).json({ error: "Failed to create game" });
  }
});

module.exports = router;