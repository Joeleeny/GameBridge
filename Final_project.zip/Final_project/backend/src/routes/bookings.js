const express = require("express");
const router = express.Router();
const db = require("../config/db");

// GET all bookings
router.get("/", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT
        b.booking_id,
        CONCAT(s.first_name, ' ', s.last_name) AS senior_name,
        c.console_name,
        b.booking_date,
        b.due_date,
        b.return_date,
        b.number_of_players,
        b.status
      FROM bookings b
      JOIN seniors s ON b.senior_id = s.senior_id
      LEFT JOIN consoles c ON b.console_id = c.console_id
      ORDER BY b.booking_id DESC
    `);

    res.json(rows);
  } catch (error) {
    console.error("Error fetching bookings:", error);
    res.status(500).json({ error: "Failed to fetch bookings" });
  }
});

// POST create booking
router.post("/", async (req, res) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    const {
      senior_id,
      console_id,
      booking_date,
      due_date,
      number_of_players,
      games,
      notes
    } = req.body;

    if (!senior_id || !booking_date || !due_date) {
      await connection.rollback();
      return res.status(400).json({
        error: "senior_id, booking_date, and due_date are required"
      });
    }

    let consoleData = null;

    if (console_id) {
      const [consoleRows] = await connection.query(
        `SELECT * FROM consoles WHERE console_id = ?`,
        [console_id]
      );

      if (consoleRows.length === 0) {
        await connection.rollback();
        return res.status(404).json({ error: "Console not found" });
      }

      consoleData = consoleRows[0];

      if (consoleData.quantity_available <= 0) {
        await connection.rollback();
        return res.status(400).json({ error: "Console is not available" });
      }

      if ((number_of_players || 1) > consoleData.max_players) {
        await connection.rollback();
        return res.status(400).json({
          error: `Max players for this console is ${consoleData.max_players}`
        });
      }
    }

    const [bookingResult] = await connection.query(
      `
      INSERT INTO bookings (
        senior_id,
        console_id,
        booking_date,
        due_date,
        number_of_players,
        status,
        notes
      )
      VALUES (?, ?, ?, ?, ?, 'booked', ?)
      `,
      [
        senior_id,
        console_id || null,
        booking_date,
        due_date,
        number_of_players || 1,
        notes || null
      ]
    );

    const bookingId = bookingResult.insertId;

    if (games && games.length > 0) {
      for (const item of games) {
        const [gameRows] = await connection.query(
          `SELECT * FROM games WHERE game_id = ?`,
          [item.game_id]
        );

        if (gameRows.length === 0) {
          await connection.rollback();
          return res.status(404).json({
            error: `Game ID ${item.game_id} not found`
          });
        }

        const game = gameRows[0];
        const qty = item.quantity || 1;

        if (game.quantity_available < qty) {
          await connection.rollback();
          return res.status(400).json({
            error: `${game.game_title} not enough stock`
          });
        }

        if (consoleData && game.platform !== consoleData.platform) {
          await connection.rollback();
          return res.status(400).json({
            error: `${game.game_title} does not match console platform`
          });
        }

        await connection.query(
          `INSERT INTO booking_games (booking_id, game_id, quantity)
           VALUES (?, ?, ?)`,
          [bookingId, item.game_id, qty]
        );

        await connection.query(
          `UPDATE games
           SET quantity_available = quantity_available - ?
           WHERE game_id = ?`,
          [qty, item.game_id]
        );
      }
    }

    if (console_id) {
      await connection.query(
        `UPDATE consoles
         SET quantity_available = quantity_available - 1
         WHERE console_id = ?`,
        [console_id]
      );
    }

    await connection.commit();

    res.status(201).json({
      message: "Booking created successfully",
      booking_id: bookingId
    });
  } catch (error) {
    await connection.rollback();
    console.error("Booking error:", error);
    res.status(500).json({ error: "Failed to create booking" });
  } finally {
    connection.release();
  }
});

// PUT return booking
router.put("/:id/return", async (req, res) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // get booking
    const [bookingRows] = await connection.query(
      `SELECT * FROM bookings WHERE booking_id = ?`,
      [id]
    );

    if (bookingRows.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: "Booking not found" });
    }

    const booking = bookingRows[0];

    if (booking.status === "returned") {
      await connection.rollback();
      return res.status(400).json({
        error: "Booking already returned"
      });
    }

    // update booking
    await connection.query(
      `
      UPDATE bookings
      SET status = 'returned',
          return_date = CURDATE()
      WHERE booking_id = ?
      `,
      [id]
    );

    // restore console
    if (booking.console_id) {
      await connection.query(
        `
        UPDATE consoles
        SET quantity_available = quantity_available + 1
        WHERE console_id = ?
        `,
        [booking.console_id]
      );
    }

    // restore games
    const [gameRows] = await connection.query(
      `SELECT * FROM booking_games WHERE booking_id = ?`,
      [id]
    );

    for (const item of gameRows) {
      await connection.query(
        `
        UPDATE games
        SET quantity_available = quantity_available + ?
        WHERE game_id = ?
        `,
        [item.quantity, item.game_id]
      );
    }

    await connection.commit();

    res.json({
      message: "Booking returned successfully"
    });

  } catch (error) {
    await connection.rollback();
    console.error("Return error:", error);
    res.status(500).json({ error: "Failed to return booking" });
  } finally {
    connection.release();
  }
});

module.exports = router;