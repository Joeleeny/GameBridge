const express = require("express");
const router = express.Router();
const db = require("../config/db");

router.get("/", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        s.senior_id,
        s.first_name,
        s.last_name,
        s.phone,
        s.email,
        s.address,
        s.date_of_birth,
        s.student_rep_id,
        s.emergency_contact_name,
        s.emergency_contact_phone,
        s.notes
      FROM seniors s
      ORDER BY s.senior_id
    `);

    res.json(rows);
  } catch (error) {
    console.error("Error fetching seniors:", error);
    res.status(500).json({ error: "Failed to fetch seniors" });
  }
});

module.exports = router;

router.post("/", async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      phone,
      email,
      address,
      date_of_birth,
      student_rep_id,
      emergency_contact_name,
      emergency_contact_phone,
      notes
    } = req.body;

    if (!first_name || !last_name || !student_rep_id) {
      return res.status(400).json({
        error: "first_name, last_name, and student_rep_id are required"
      });
    }

    const [result] = await db.query(
      `
      INSERT INTO seniors (
        first_name,
        last_name,
        phone,
        email,
        address,
        date_of_birth,
        student_rep_id,
        emergency_contact_name,
        emergency_contact_phone,
        notes
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        first_name,
        last_name,
        phone || null,
        email || null,
        address || null,
        date_of_birth || null,
        student_rep_id,
        emergency_contact_name || null,
        emergency_contact_phone || null,
        notes || null
      ]
    );

    res.status(201).json({
      message: "Senior created successfully",
      senior_id: result.insertId
    });
  } catch (error) {
    console.error("Error creating senior:", error);
    res.status(500).json({ error: "Failed to create senior" });
  }
});