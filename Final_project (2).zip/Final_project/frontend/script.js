const API_URL = "http://localhost:5000/api";

// load seniors
async function loadSeniors() {
  try {
    const res = await fetch(`${API_URL}/seniors`);
    const data = await res.json();

    const tableBody = document.querySelector("#seniorsTable tbody");
    tableBody.innerHTML = "";

    data.forEach(senior => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${senior.senior_id}</td>
        <td>${senior.first_name} ${senior.last_name}</td>
        <td>${senior.phone || ""}</td>
        <td>${senior.email || ""}</td>
      `;

      tableBody.appendChild(row);
    });

  } catch (error) {
    console.error("Error loading seniors:", error);
  }
}

// run on page load
loadSeniors();
const form = document.getElementById("seniorForm");

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const newSenior = {
    first_name: document.getElementById("first_name").value,
    last_name: document.getElementById("last_name").value,
    phone: document.getElementById("phone").value,
    email: document.getElementById("email").value,
    address: document.getElementById("address").value,
    date_of_birth: document.getElementById("date_of_birth").value,
    student_rep_id: parseInt(document.getElementById("student_rep_id").value),
    emergency_contact_name: document.getElementById("emergency_contact_name").value,
    emergency_contact_phone: document.getElementById("emergency_contact_phone").value,
    notes: document.getElementById("notes").value
  };

  try {
    const res = await fetch(`${API_URL}/seniors`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(newSenior)
    });

    const data = await res.json();

    alert(data.message);

    form.reset();
    loadSeniors(); // refresh table

  } catch (error) {
    console.error("Error adding senior:", error);
  }
});
async function loadDropdowns() {
  // seniors
  const seniorsRes = await fetch(`${API_URL}/seniors`);
  const seniors = await seniorsRes.json();

  const seniorSelect = document.getElementById("senior_id");
  seniorSelect.innerHTML = "";

  seniors.forEach(s => {
    const option = document.createElement("option");
    option.value = s.senior_id;
    option.textContent = `${s.first_name} ${s.last_name}`;
    seniorSelect.appendChild(option);
  });

  // consoles
  const consolesRes = await fetch(`${API_URL}/consoles`);
  const consoles = await consolesRes.json();

  const consoleSelect = document.getElementById("console_id");
  consoleSelect.innerHTML = '<option value="">No Console</option>';

  consoles.forEach(c => {
    const option = document.createElement("option");
    option.value = c.console_id;
    option.textContent = `${c.console_name} (${c.platform})`;
    consoleSelect.appendChild(option);
  });

  // games
  const gamesRes = await fetch(`${API_URL}/games`);
  const games = await gamesRes.json();

  const gamesSelect = document.getElementById("games");
  gamesSelect.innerHTML = "";

  games.forEach(g => {
    const option = document.createElement("option");
    option.value = g.game_id;
    option.textContent = `${g.game_title} (${g.platform})`;
    gamesSelect.appendChild(option);
  });
}
document.getElementById("bookingForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const selectedGames = Array.from(document.getElementById("games").selectedOptions)
    .map(opt => ({
      game_id: parseInt(opt.value),
      quantity: 1
    }));

  const booking = {
    senior_id: parseInt(document.getElementById("senior_id").value),
    console_id: document.getElementById("console_id").value || null,
    booking_date: document.getElementById("booking_date").value,
    due_date: document.getElementById("due_date").value,
    number_of_players: parseInt(document.getElementById("number_of_players").value) || 1,
    games: selectedGames
  };

  try {
    const res = await fetch(`${API_URL}/bookings`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(booking)
    });

    const data = await res.json();

    alert(data.message);
    loadBookings();
    loadDropdowns();
    document.getElementById("bookingForm").reset();

  } catch (error) {
    console.error("Error creating booking:", error);
  }
});
loadDropdowns();
async function loadBookings() {
  try {
    const res = await fetch(`${API_URL}/bookings`);
    const data = await res.json();

    const tableBody = document.querySelector("#bookingsTable tbody");
    tableBody.innerHTML = "";

    data.forEach(booking => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${booking.booking_id}</td>
        <td>${booking.senior_name || ""}</td>
        <td>${booking.console_name || "No Console"}</td>
        <td>${booking.booking_date ? booking.booking_date.split("T")[0] : ""}</td>
        <td>${booking.due_date ? booking.due_date.split("T")[0] : ""}</td>
        <td>${booking.number_of_players || 1}</td>
        <td>${booking.status || ""}</td>
        <td>
          ${
            booking.status !== "returned"
              ? `<button onclick="returnBooking(${booking.booking_id})">Return</button>`
              : "Returned"
          }
        </td>
      `;

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Error loading bookings:", error);
  }
}

async function returnBooking(bookingId) {
  try {
    const res = await fetch(`${API_URL}/bookings/${bookingId}/return`, {
      method: "PUT"
    });

    const data = await res.json();
    alert(data.message);

    loadBookings();
    loadSeniors();
    loadDropdowns();
  } catch (error) {
    console.error("Error returning booking:", error);
  }
}
async function loadGames() {
  try {
    const res = await fetch(`${API_URL}/games`);
    const data = await res.json();

    const tableBody = document.querySelector("#gamesTable tbody");
    tableBody.innerHTML = "";

    data.forEach(game => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${game.game_id}</td>
        <td>${game.game_title}</td>
        <td>${game.genre || ""}</td>
        <td>${game.platform || ""}</td>
        <td>${game.quantity_available ?? ""}</td>
        <td>${game.quantity_total ?? ""}</td>
        <td>${game.status || ""}</td>
      `;

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Error loading games:", error);
  }
}
document.getElementById("gameForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const newGame = {
    game_title: document.getElementById("game_title").value,
    genre: document.getElementById("genre").value,
    platform: document.getElementById("game_platform").value,
    age_rating: document.getElementById("age_rating").value,
    quantity_total: parseInt(document.getElementById("quantity_total").value),
    quantity_available: parseInt(document.getElementById("quantity_available").value),
    status: document.getElementById("game_status").value || "available",
    condition_notes: document.getElementById("game_condition_notes").value
  };

  try {
    const res = await fetch(`${API_URL}/games`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(newGame)
    });

    const data = await res.json();
    alert(data.message);

    document.getElementById("gameForm").reset();
    loadGames();
    loadDropdowns();
  } catch (error) {
    console.error("Error adding game:", error);
  }
});
async function loadConsoles() {
  try {
    const res = await fetch(`${API_URL}/consoles`);
    const data = await res.json();

    const tableBody = document.querySelector("#consolesTable tbody");
    tableBody.innerHTML = "";

    data.forEach(consoleItem => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${consoleItem.console_id}</td>
        <td>${consoleItem.console_name}</td>
        <td>${consoleItem.brand || ""}</td>
        <td>${consoleItem.platform || ""}</td>
        <td>${consoleItem.quantity_available ?? ""}</td>
        <td>${consoleItem.quantity_total ?? ""}</td>
        <td>${consoleItem.max_players ?? ""}</td>
        <td>${consoleItem.status || ""}</td>
      `;

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Error loading consoles:", error);
  }
}
document.getElementById("consoleForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const newConsole = {
    console_name: document.getElementById("console_name").value,
    brand: document.getElementById("brand").value,
    platform: document.getElementById("console_platform").value,
    quantity_total: parseInt(document.getElementById("console_quantity_total").value),
    quantity_available: parseInt(document.getElementById("console_quantity_available").value),
    max_players: parseInt(document.getElementById("max_players").value),
    status: document.getElementById("console_status").value || "available",
    condition_notes: document.getElementById("console_condition_notes").value
  };

  try {
    const res = await fetch(`${API_URL}/consoles`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(newConsole)
    });

    const data = await res.json();
    alert(data.message);

    document.getElementById("consoleForm").reset();
    loadConsoles();
    loadDropdowns();
  } catch (error) {
    console.error("Error adding console:", error);
  }
});
loadSeniors();
loadDropdowns();
loadBookings();
loadGames();
loadConsoles();